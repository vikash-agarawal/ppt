package Tags;

import cucumber.api.java.en.Given;

public class Stepdef {
	@Given("^This is a blank test$")
	public void this_is_a_blank_test() throws Throwable {
	    
	}
}
