package webDriver;




import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class WorkingWithForms {
	public static void main(String args[]) throws InterruptedException
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\VIKAAGRA\\Desktop\\BDD\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/VIKAAGRA/Desktop/BDD/WorkingWithForms.html");
		
		driver.findElement(By.id("txtUserName")).sendKeys("Vikash Agrawal");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtPassword")).sendKeys("123");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtConfPassword")).sendKeys("123");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtFirstName")).sendKeys("Vikash");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtLastName")).sendKeys("Agrawal");
		Thread.sleep(1000);
		
		driver.findElement(By.cssSelector("input[value='Male']")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.id("DOB")).sendKeys("03/07/1997");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtEmail")).sendKeys("abc@gmail.com");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtAddress")).sendKeys("Tilak Nagar");
		Thread.sleep(1000);
		
		
		Select drpCity=new Select(driver.findElement(By.name("City")));
		//drpCity.selectByVisibleText("Mumbai");
		drpCity.selectByIndex(1);
		Thread.sleep(1000);
		
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("1234567891");
		Thread.sleep(1000);
		
		driver.findElement(By.cssSelector("input[value='Reading']")).click();
		//List<WebElement> element=driver.findElements(By.name("chkHobbies"));
		Thread.sleep(1000);
		
		driver.findElement(By.name("reset")).click();
	}
	
}
