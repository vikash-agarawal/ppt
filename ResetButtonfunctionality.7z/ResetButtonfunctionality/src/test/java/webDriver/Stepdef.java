package webDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	WebDriver driver;
	@Given("^Open the firefox and launch the application$")
	public void open_the_firefox_and_launch_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\VIKAAGRA\\Desktop\\BDD\\chromedriver.exe");
		driver=new ChromeDriver();
		//driver.manage().timeouts();
		driver.get("file:///C:/Users/VIKAAGRA/Desktop/BDD/WorkingWithForms.html");
	}

	@When("^enter the username,password,confirmPassword,First name,Last name,gender,dob,email,address,city,phone and hobbies$")
	public void enter_the_username_password_confirmPassword_First_name_Last_name_gender_dob_email_address_city_phone_and_hobbies() throws Throwable {
		driver.findElement(By.id("txtUserName")).sendKeys("Vikash Agrawal");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtPassword")).sendKeys("123");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtConfPassword")).sendKeys("123");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtFirstName")).sendKeys("Vikash");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtLastName")).sendKeys("Agrawal");
		Thread.sleep(1000);
		
		driver.findElement(By.cssSelector("input[value='Male']")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.id("DOB")).sendKeys("03/07/1997");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtEmail")).sendKeys("abc@gmail.com");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtAddress")).sendKeys("Tilak Nagar");
		Thread.sleep(1000);
		
		
		Select drpCity=new Select(driver.findElement(By.name("City")));
		//drpCity.selectByVisibleText("Mumbai");
		drpCity.selectByIndex(1);
		Thread.sleep(1000);
		
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("1234567891");
		Thread.sleep(1000);
		
		driver.findElement(By.cssSelector("input[value='Reading']")).click();
		//List<WebElement> element=driver.findElements(By.name("chkHobbies"));
		Thread.sleep(1000);  
	}

	@Then("^Reset the Credential$")
	public void reset_the_Credential() throws Throwable {
		driver.findElement(By.name("reset")).click();
	}
}