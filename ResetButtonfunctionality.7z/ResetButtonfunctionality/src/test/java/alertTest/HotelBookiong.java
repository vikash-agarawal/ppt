package alertTest;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HotelBookiong {
	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\VIKAAGRA\\Desktop\\BDD\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/VIKAAGRA/Desktop/BDD/hotelbooking.html");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtFirstName")).sendKeys();
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		callAlert();
		
		driver.findElement(By.id("txtFirstName")).sendKeys("vikash");
		driver.findElement(By.id("txtLastName")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		callAlert();
		
		driver.findElement(By.id("txtLastName")).sendKeys("Agrawal");
		driver.findElement(By.id("txtEmail")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		callAlert();
		
		driver.findElement(By.id("txtEmail")).sendKeys("abc@gmail.com");
		driver.findElement(By.id("txtPhone")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		callAlert();
		
		driver.findElement(By.id("txtPhone")).sendKeys("1234567891");
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		callAlert();
		
		driver.findElement(By.id("txtPhone")).clear();
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("78945612");
		driver.findElement(By.id("btnPayment")).click();
		Thread.sleep(1000);
		callAlert();
		
	}
	public static void callAlert()
	{
		String alertmessage=driver.switchTo().alert().getText();
		System.out.println(alertmessage);
		driver.switchTo().alert().accept();
	}

}
