package scenario;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef2 
{
	WebDriver driver;
	@Given("^open the Firefox and launch tha application$")
	public void open_the_Firefox_and_launch_tha_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\VIKAAGRA\\Desktop\\BDD\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///C:/Users/VIKAAGRA/Desktop/BDD/WorkingWithForms.html");
	}

	@When("^enter the username and pasword$")
	public void enter_the_username_and_pasword(DataTable arg1) throws Throwable {
	    List<List<String>> data=arg1.raw();
	    for(int i=0;i<data.size();i++)
	    {
	    	driver.findElement(By.id("txtUserName")).clear();
	    	driver.findElement(By.id("txtPassword")).clear();
	    	driver.findElement(By.id("txtUserName")).sendKeys(data.get(i).get(0));
	    	driver.findElement(By.id("txtPassword")).sendKeys(data.get(i).get(1));
	    }
	}

	@Then("^Reset the credential$")
	public void reset_the_credential() throws Throwable {
		driver.findElement(By.name("reset")).click();
	}



}
